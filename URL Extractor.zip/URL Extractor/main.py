import re
import os.path
file=input("Enter File Name");
if(os.path.isfile(file)):
    f = open(file)
    for line in f:
        urls = re.findall('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+', line)
    print(urls[0])
else:
    print("sorry ..file Not Found")
